// Animate profile photo and texts on load
window.addEventListener('DOMContentLoaded', ()=> {
  const photo = document.querySelector('.profile-photo');
  const name = document.querySelector('.name');
  const tagline = document.querySelector('.tagline');
  const lead = document.querySelector('.lead');

  // initial states via CSS transitions - add classes to animate in
  setTimeout(()=> photo.classList.add('animate-in'), 200);
  setTimeout(()=> name.classList.add('text-appear'), 450);
  setTimeout(()=> tagline.classList.add('text-appear'), 600);
  setTimeout(()=> lead.classList.add('text-appear'), 800);
});

// Lightbox for gallery
document.querySelectorAll('.gallery-item').forEach(item => {
  item.addEventListener('click', ()=> {
    const img = item.querySelector('img');
    const cap = item.querySelector('figcaption').textContent;
    const lb = document.getElementById('lightbox');
    document.getElementById('lbImage').src = img.src;
    document.getElementById('lbCaption').textContent = cap;
    lb.classList.add('active');
    lb.setAttribute('aria-hidden','false');
  });
});
document.getElementById('lbClose').addEventListener('click', ()=> {
  const lb = document.getElementById('lightbox');
  lb.classList.remove('active');
  lb.setAttribute('aria-hidden','true');
});

// Contact form demo & save to localStorage
const form = document.getElementById('contactForm');
form && form.addEventListener('submit', e => {
  e.preventDefault();
  alert('Pesan dikirim (demo). Tidak ada pengiriman ke server pada versi ini.');
});
document.getElementById('saveLocal')?.addEventListener('click', ()=> {
  const f = document.getElementById('contactForm');
  if(!f) return;
  const data = {name:f.name.value,email:f.email.value,message:f.message.value,time:new Date().toISOString()};
  localStorage.setItem('contactDraft', JSON.stringify(data));
  alert('Tersimpan di browser (localStorage).');
});

// mobile menu toggle
document.getElementById('menuBtn')?.addEventListener('click', ()=> {
  const nav = document.querySelector('.nav');
  if(nav.style.display === 'flex') nav.style.display = 'none';
  else nav.style.display = 'flex';
});
